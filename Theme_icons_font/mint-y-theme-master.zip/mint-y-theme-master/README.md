Credits
=======

This theme is based on the Arc theme: <br>
&emsp;&emsp; Link: https://github.com/horst3180/arc-theme <br>
&emsp;&emsp; Author: horst3180 http://horst3180.deviantart.com/ <br>
&emsp;&emsp; License: GPL v3

Editing
=======

Do not make modifications to the theme directly in the usr/share/themes directory. These are automatically generated from the files located in the src/ directory. Each subdirectory contains its own individual instructions on how to edit. Once edits are made you can generate the final themes by running the build-themes.py script.
