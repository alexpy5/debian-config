#! /bin/bash

sass --sourcemap=none --update ./sass:.